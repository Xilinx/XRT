var searchData=
[
  ['memory_5fgroup_334',['memory_group',['../namespacexrt.html#a0b5c34a203355370d2901d9e6100f287',1,'xrt']]]
];
