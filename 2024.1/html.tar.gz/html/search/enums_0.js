var searchData=
[
  ['control_5ftype_346',['control_type',['../classxrt_1_1xclbin_1_1ip.html#a075ba9da9ca0076d04968e462f17132a',1,'xrt::xclbin::ip']]],
  ['cu_5faccess_5fmode_347',['cu_access_mode',['../classxrt_1_1kernel.html#a77e6ff3b69b1ff2365464f483b5b7dd6',1,'xrt::kernel']]]
];
