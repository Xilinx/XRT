var searchData=
[
  ['thermal_407',['thermal',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aa26a27f04d02b653b4b5b77b5d11d7bb9',1,'xrt::info']]]
];
