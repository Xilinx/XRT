var searchData=
[
  ['shared_402',['shared',['../classxrt_1_1kernel.html#a77e6ff3b69b1ff2365464f483b5b7dd6a9e81e7b963c71363e2fb3eefcfecfc0e',1,'xrt::kernel']]],
  ['streaming_403',['streaming',['../classxrt_1_1xclbin_1_1mem.html#a4ae64153a1751d25c9b8e95fb3c7525faabb0256a318439745ab0b343d64b9ba0',1,'xrt::xclbin::mem']]],
  ['streaming_5fconnection_404',['streaming_connection',['../classxrt_1_1xclbin_1_1mem.html#a4ae64153a1751d25c9b8e95fb3c7525fa61a2f203e2ab90e668be5b244ff0215e',1,'xrt::xclbin::mem']]],
  ['svm_405',['svm',['../classxrt_1_1bo.html#ad6a4bb086ce3b1023df8671c29a1d1dda924ff83ff1e671bacfb07ff12b845703',1,'xrt::bo']]],
  ['sw_5femu_406',['sw_emu',['../classxrt_1_1xclbin.html#a0746e80e19df9bebf75e08af51e4401da95c104ccd3426696d51fd70c33557992',1,'xrt::xclbin']]]
];
