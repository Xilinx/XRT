var searchData=
[
  ['vmr_409',['vmr',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aa4a64b1714b324eda3928be5f063f7b59',1,'xrt::info']]]
];
