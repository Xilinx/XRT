var searchData=
[
  ['bdf_360',['bdf',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aa865fe807bb0ed8ffba5fcfd7c12269f5',1,'xrt::info']]],
  ['bram_361',['bram',['../classxrt_1_1xclbin_1_1mem.html#a4ae64153a1751d25c9b8e95fb3c7525fae4fa3adecabcf036f6f95da68bfe76bb',1,'xrt::xclbin::mem']]]
];
