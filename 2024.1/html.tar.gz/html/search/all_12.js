var searchData=
[
  ['update_5farg_159',['update_arg',['../classxrt_1_1run.html#a53ee8f980ab4730a247015501feee605',1,'xrt::run::update_arg(int index, ArgType &amp;&amp;arg)'],['../classxrt_1_1run.html#a15fa11c122834664d7d24c7c2867c834',1,'xrt::run::update_arg(int index, const xrt::bo &amp;boh)'],['../classxrt_1_1run.html#ada1100dcaec6d37d228665388d53114c',1,'xrt::run::update_arg(int index, const void *value, size_t bytes)']]],
  ['uram_160',['uram',['../classxrt_1_1xclbin_1_1mem.html#a4ae64153a1751d25c9b8e95fb3c7525fa2d7c24ccabd5da82aa90c666185c369d',1,'xrt::xclbin::mem']]],
  ['uuid_161',['uuid',['../classxrt_1_1uuid.html#a1163ac3774ae5c0b8cdd5e234cffac41',1,'xrt::uuid::uuid()'],['../classxrt_1_1uuid.html#a480b5282c41ecade2cf776154048be1e',1,'xrt::uuid::uuid(const xuid_t val)'],['../classxrt_1_1uuid.html#a4ae6e1a315586cdb161c9723b7a9804f',1,'xrt::uuid::uuid(const std::string &amp;uuid_str)'],['../classxrt_1_1uuid.html#ac6bdba3aa789eb57379b0f5105dbe25f',1,'xrt::uuid::uuid(const uuid &amp;rhs)'],['../classxrt_1_1uuid.html',1,'xrt::uuid']]]
];
