var searchData=
[
  ['uram_408',['uram',['../classxrt_1_1xclbin_1_1mem.html#a4ae64153a1751d25c9b8e95fb3c7525fa2d7c24ccabd5da82aa90c666185c369d',1,'xrt::xclbin::mem']]]
];
