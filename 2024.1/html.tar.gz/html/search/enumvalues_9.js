var searchData=
[
  ['m2m_386',['m2m',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aa4d65d483f53fd19eea5625721976b41e',1,'xrt::info']]],
  ['max_5fclock_5ffrequency_5fmhz_387',['max_clock_frequency_mhz',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aacd6586634142c1d1c7e85e35d96d329f',1,'xrt::info']]],
  ['mechanical_388',['mechanical',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aa7e3fdeae0d52916ea5c86c7e5291f5be',1,'xrt::info']]],
  ['memory_389',['memory',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aacd69b4957f06cd818d7bf3d61980e291',1,'xrt::info']]]
];
