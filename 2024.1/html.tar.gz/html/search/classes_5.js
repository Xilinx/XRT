var searchData=
[
  ['kernel_207',['kernel',['../classxrt_1_1kernel.html',1,'xrt::kernel'],['../classxrt_1_1xclbin_1_1kernel.html',1,'xrt::xclbin::kernel']]]
];
