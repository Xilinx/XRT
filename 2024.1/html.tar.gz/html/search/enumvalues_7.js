var searchData=
[
  ['info_383',['info',['../namespacexrt_1_1message.html#a6f303f50c0aeef482a843e18a0f24f4cacaf9b6b99962bf5c2264824231d7a40c',1,'xrt::message']]],
  ['interface_5fuuid_384',['interface_uuid',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aa61854ba7128cbadc36f4c5fa94a44e84',1,'xrt::info']]]
];
