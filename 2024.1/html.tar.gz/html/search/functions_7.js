var searchData=
[
  ['kernel_287',['kernel',['../classxrt_1_1kernel.html#a1f819540d433c87f27067166ab1e8bff',1,'xrt::kernel::kernel()=default'],['../classxrt_1_1kernel.html#a32cc9ecb08ec3c5da84d3d6b10b3a074',1,'xrt::kernel::kernel(const xrt::device &amp;device, const xrt::uuid &amp;xclbin_id, const std::string &amp;name, cu_access_mode mode=cu_access_mode::shared)'],['../classxrt_1_1xclbin_1_1kernel.html#aca6d5209b7075863fa5e83a4f2a40c76',1,'xrt::xclbin::kernel::kernel()=default'],['../classxrt_1_1xclbin_1_1kernel.html#aeb4e6d106e71f065bcac36e0d34fc144',1,'xrt::xclbin::kernel::kernel(std::shared_ptr&lt; kernel_impl &gt; handle)']]]
];
