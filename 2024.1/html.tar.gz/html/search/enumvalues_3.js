var searchData=
[
  ['ddr3_365',['ddr3',['../classxrt_1_1xclbin_1_1mem.html#a4ae64153a1751d25c9b8e95fb3c7525fa9ea5bdd29692f10540ec3ce4d8ba97f5',1,'xrt::xclbin::mem']]],
  ['ddr4_366',['ddr4',['../classxrt_1_1xclbin_1_1mem.html#a4ae64153a1751d25c9b8e95fb3c7525fa59a98898efc5226d57d2da1e7c4444d4',1,'xrt::xclbin::mem']]],
  ['debug_367',['debug',['../namespacexrt_1_1message.html#a6f303f50c0aeef482a843e18a0f24f4caad42f6697b035b7580e4fef93be20b4d',1,'xrt::message']]],
  ['device_5fonly_368',['device_only',['../classxrt_1_1bo.html#ad6a4bb086ce3b1023df8671c29a1d1ddac50c88b7e991886fcc6a60e4ba12a375',1,'xrt::bo']]],
  ['dpu_369',['dpu',['../classxrt_1_1xclbin_1_1kernel.html#aae7991bdd065bcf6d2f8d7ff1716c6a1a225734fb10a045efb6e591ef55b939a7',1,'xrt::xclbin::kernel']]],
  ['dram_370',['dram',['../classxrt_1_1xclbin_1_1mem.html#a4ae64153a1751d25c9b8e95fb3c7525fafb5914622a6a9112bc77a767112a6dfc',1,'xrt::xclbin::mem']]],
  ['dynamic_5fregions_371',['dynamic_regions',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aabf6e19331b5e8553e0cb930c1457eb3d',1,'xrt::info']]]
];
