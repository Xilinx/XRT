var searchData=
[
  ['memory_5ftype_353',['memory_type',['../classxrt_1_1xclbin_1_1mem.html#a4ae64153a1751d25c9b8e95fb3c7525f',1,'xrt::xclbin::mem']]]
];
