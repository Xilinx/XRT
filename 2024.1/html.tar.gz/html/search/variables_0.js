var searchData=
[
  ['bhdl_328',['bhdl',['../structxcl__buffer__handle.html#a076aa7e2ed0e4ba2075a13a3060294ee',1,'xcl_buffer_handle']]]
];
