var searchData=
[
  ['p2p_396',['p2p',['../classxrt_1_1bo.html#ad6a4bb086ce3b1023df8671c29a1d1dda705bcf0e77bc8b6fc8e66cbf3c055e6c',1,'xrt::bo']]],
  ['pcie_5finfo_397',['pcie_info',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aab44657f9077b7ce4684c449e5144e02e',1,'xrt::info']]],
  ['pl_398',['pl',['../classxrt_1_1xclbin_1_1ip.html#a5f85716a30bb8c0fc6768969827c1b74a288404204e3d452229308317344a285d',1,'xrt::xclbin::ip::pl()'],['../classxrt_1_1xclbin_1_1kernel.html#aae7991bdd065bcf6d2f8d7ff1716c6a1a288404204e3d452229308317344a285d',1,'xrt::xclbin::kernel::pl()']]],
  ['platform_399',['platform',['../namespacexrt_1_1info.html#a7a27ce3a06c2a28f53579eb4f02a829aa34a6e5d64ade17ef4e51612c50dd72f5',1,'xrt::info']]],
  ['preallocated_5fglobal_400',['preallocated_global',['../classxrt_1_1xclbin_1_1mem.html#a4ae64153a1751d25c9b8e95fb3c7525fa57fd539060b8a2bf98cd42880f8846d2',1,'xrt::xclbin::mem']]],
  ['ps_401',['ps',['../classxrt_1_1xclbin_1_1ip.html#a5f85716a30bb8c0fc6768969827c1b74a8812c36aa5ae336c2a77bf63211d899a',1,'xrt::xclbin::ip::ps()'],['../classxrt_1_1xclbin_1_1kernel.html#aae7991bdd065bcf6d2f8d7ff1716c6a1a8812c36aa5ae336c2a77bf63211d899a',1,'xrt::xclbin::kernel::ps()']]]
];
