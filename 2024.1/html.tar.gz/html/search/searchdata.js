var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwx~",
  1: "abcdikmprux",
  2: "x",
  3: "x",
  4: "abcdegiklmoprstuwx~",
  5: "bip",
  6: "deimprvx",
  7: "cdfiklmt",
  8: "abcdefhikmnopstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator"
};

