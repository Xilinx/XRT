var searchData=
[
  ['kernel_5ftype_351',['kernel_type',['../classxrt_1_1xclbin_1_1kernel.html#aae7991bdd065bcf6d2f8d7ff1716c6a1',1,'xrt::xclbin::kernel']]]
];
