var searchData=
[
  ['abort_232',['abort',['../classxrt_1_1run.html#ac4697b4f95bbb0d67711772ced21b1cd',1,'xrt::run']]],
  ['add_5fcallback_233',['add_callback',['../classxrt_1_1run.html#a268c7ad2d9bab32d6ba2878a0b00c628',1,'xrt::run']]],
  ['address_234',['address',['../classxrt_1_1bo.html#a2b1832f158dd96cf86fe6dd72c6be9fd',1,'xrt::bo']]],
  ['arg_235',['arg',['../classxrt_1_1xclbin_1_1arg.html#ace0c1022e0b56765d9bfb8c4a887b24c',1,'xrt::xclbin::arg::arg()=default'],['../classxrt_1_1xclbin_1_1arg.html#a8026afcbfc713a2c5abaef57b126ad82',1,'xrt::xclbin::arg::arg(std::shared_ptr&lt; arg_impl &gt; handle)']]],
  ['async_236',['async',['../classxrt_1_1bo.html#a1c360b1550ef213cc59d5920b0febf5e',1,'xrt::bo::async(xclBOSyncDirection dir, size_t sz, size_t offset)'],['../classxrt_1_1bo.html#a7d4aea62bbe1c6ac33f71d2ccf84b06f',1,'xrt::bo::async(xclBOSyncDirection dir)']]],
  ['async_5fhandle_237',['async_handle',['../classxrt_1_1bo_1_1async__handle.html#a2b6ac7716242ebe5f1767b711cdbcf4c',1,'xrt::bo::async_handle']]]
];
