var searchData=
[
  ['xrtbufferflags_338',['xrtBufferFlags',['../xrt__bo_8h.html#af7e1ca20dfcae346ed803426494c5b91',1,'xrt_bo.h']]],
  ['xrtbufferhandle_339',['xrtBufferHandle',['../xrt__bo_8h.html#a0e7088a86bb6c894941629d2870c9e15',1,'xrt_bo.h']]],
  ['xrtdevicehandle_340',['xrtDeviceHandle',['../xrt__device_8h.html#adfe3b0114657bf4f06299bf397c0d4e0',1,'xrtDeviceHandle():&#160;xrt_device.h'],['../xrt__bo_8h.html#adfe3b0114657bf4f06299bf397c0d4e0',1,'xrtDeviceHandle():&#160;xrt_bo.h']]],
  ['xrtkernelhandle_341',['xrtKernelHandle',['../xrt__kernel_8h.html#a68e3a9b09a4c5ce69eda646169ea6a49',1,'xrt_kernel.h']]],
  ['xrtmemorygroup_342',['xrtMemoryGroup',['../xrt__bo_8h.html#acf6299e759d81e5d27853480153c8d11',1,'xrt_bo.h']]],
  ['xrtrunhandle_343',['xrtRunHandle',['../xrt__kernel_8h.html#ada8884bce9b6c6dbc1d7497d68845061',1,'xrt_kernel.h']]],
  ['xrtxclbinhandle_344',['xrtXclbinHandle',['../xrt__xclbin_8h.html#ad160435afaebb750f12f2478bbf29f0a',1,'xrt_xclbin.h']]],
  ['xuid_5ft_345',['xuid_t',['../xrt__uuid_8h.html#acc1e121f6e46b5d2345dc98581dd712d',1,'xrt_uuid.h']]]
];
