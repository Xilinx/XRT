var searchData=
[
  ['xcl_5fbuffer_5fhandle_213',['xcl_buffer_handle',['../structxcl__buffer__handle.html',1,'']]],
  ['xclbin_214',['xclbin',['../classxrt_1_1xclbin.html',1,'xrt']]],
  ['xclbin_5frepository_215',['xclbin_repository',['../classxrt_1_1xclbin__repository.html',1,'xrt']]]
];
